 Frost 4k Intro
 (C)2000 FeNoMen. Mad Rain.
 
 Converted from Alasm to SjASMPlus by Aprisobal (2006)
 
 To compile this program you must run SjASMPlus so:
>> sjasmplus.exe frost10.asm
 and SjASMPlus will generate a snapshot file frost10.sna